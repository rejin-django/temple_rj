import { THEME } from "@theme/index";

export const Styles= {
    LableSize:'14px',
    LableWeight:'400',
    LableColor:THEME.black,
    labelfontfamily: 'Rubik',
    Inputfontfamily: 'Rubik',
    InputSize:'15px',
    InputWeight:'400',
    InputColor:THEME.black,
    InputPlaceholderSize:'15px',
    InputPlaceholderWeight:'500',
    InputPlaceholderColor:THEME.gray,
    Height:'45px',
    BtnHeight:'50px',
    BtnSize:'16px',
    BtnWeight:'600',
    BrowserColor:'#990000',
    Browserweight:'600'
}