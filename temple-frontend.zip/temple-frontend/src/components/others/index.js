export { default as CommonLoading } from '@components/others/CommonLoading'
export { default as CustomBadge } from '@components/others/CustomBadge'
export { default as CustomCardView } from '@components/others/CustomCardView'
export { default as CustomModal } from '@components/others/CustomModal'
export { default as CustomPopConfirm } from '@components/others/CustomPopConfirm'
export { default as CustomRow } from '@components/others/CustomRow'
export { default as Flex } from '@components/others/Flex'
export { default as TableImgHolder } from '@components/others/TableImgHolder'

