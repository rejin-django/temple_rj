import Avatar from './avatar.png'

export const AvImg = Avatar