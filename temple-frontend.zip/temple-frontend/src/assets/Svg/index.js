import Filter from '@assets/Svg/Filter.svg'
import DownArrow from '@assets/Svg/DownArrow.svg'
import DownArrowYellow from '@assets/Svg/DownArrowYellow.svg'
import Upload from '@assets/Svg/file.svg'
import Calender from '@assets/Svg/Calender.svg'
import Plus from '@assets/Svg/Plus.svg'
import Protein from '@assets/Svg/Protein.svg'
import Fat from '@assets/Svg/Fat.svg'
import LowCarb from '@assets/Svg/Low_carb_diet.svg'
import Logoimg from '@assets/Svg/TableIcons/dd.svg'
import HandMoney from '@assets/Svg/HandMoney.svg'
import User from '@assets/Svg/User.svg'

// Table
import Edit from '@assets/Svg/TableIcons/Edit.svg'
import Delete from '@assets/Svg/TableIcons/Delete.svg'
import Phone from '@assets/Svg/TableIcons/Phone.svg'
import Eye from '@assets/Svg/TableIcons/Eye.svg'
import UserView from '@assets/Svg/TableIcons/UserView.svg'
import MemberView from '@assets/Svg/TableIcons/memberView.svg'
import Report from '@assets/Svg/TableIcons/report.svg'
import Approve from '@assets/Svg/TableIcons/Approve.svg'
import Reject from '@assets/Svg/TableIcons/Reject.svg'
import Close from '@assets/Svg/TableIcons/Close.svg'
import Show from '@assets/Svg/Show.svg'
import bin from '@assets/Svg/Bin.svg'
import edit from '@assets/Svg/Edit Button.svg'
import HandRecord from '@assets/Svg/TableIcons/HandRecord.svg'
import ManCross from '@assets/Svg/TableIcons/ManCross.svg'
import ManTick from '@assets/Svg/TableIcons/ManTick.svg'
import Cross from '@assets/Svg/TableIcons/Cross.svg'
import RightArrow from '@assets/Svg/TableIcons/RightArrow.svg'
import Remove from '@assets/Svg/TableIcons/Remove.svg'
import Person from '@assets/Svg/TableIcons/Person.svg'
import Resign from '@assets/Svg/TableIcons/Resign.svg'
import Rejoin from '@assets/Svg/TableIcons/Rejoin.svg'
import Collection from '@assets/Svg/TableIcons/Collection.svg'
import Money from '@assets/Svg/TableIcons/Money.svg'

export const SvgIcons = {
    Filter,
    DownArrow,
    DownArrowYellow,
    Upload,
    Calender,
    Plus,
    Protein,
    Fat,
    LowCarb,
    Logoimg,
    HandMoney,
    User,

    // Table
    Edit,
    Delete,
    Phone,
    Eye,
    UserView,
    MemberView,
    Report,
    Approve,
    Reject,
    Show,
    bin,
    edit,
    Close,
    HandRecord,
    ManCross,
    ManTick, 
    Cross,  
    RightArrow, 
    Remove,
    Person,
    Resign,
    Rejoin,
    Collection,
    Money,
}
