export const userRolesConfig = {
    ADMIN : "Admin",
    USER : "User",
    INVESTOR: 'Invester',

}