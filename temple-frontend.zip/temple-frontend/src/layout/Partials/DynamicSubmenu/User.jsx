import { AiTwotoneAccountBook } from "react-icons/ai";
import { BsBoxSeam } from "react-icons/bs";
import { MenuText } from "@layout/Partials/Style";
import { MdAddchart, MdFamilyRestroom, MdGroupAdd, MdManageAccounts, MdOutlineGpsFixed, MdOutlineRateReview } from "react-icons/md";
import { HiOfficeBuilding, HiReceiptTax, HiUserGroup } from "react-icons/hi";
import {
    GiCrackedBallDunk,
    GiLandMine,
    GiMoneyStack,
    GiReceiveMoney,
    GiTakeMyMoney,
} from "react-icons/gi";
import { FaMoneyBillTrendUp, FaPeopleGroup } from "react-icons/fa6";
import {
    HiClipboardDocumentList,
    HiOutlineClipboardDocumentList,
} from "react-icons/hi2";
import { TbFileInvoice, TbHeartHandshake } from "react-icons/tb";
import { LuTableProperties } from "react-icons/lu";
import { RiFileList3Line, RiPassExpiredFill } from "react-icons/ri";
import { FaHome, FaWpforms } from "react-icons/fa";
import { GrMoney } from "react-icons/gr";

export const userItems = (collapsed, permissionsGet) => {
    function getItem(label, key, icon, children, type) {
        return {
            key,
            icon,
            children,
            label,
            type,
        };
    }

    let items = [
        getItem(
            <MenuText>{collapsed ? null : ""}</MenuText>,
            "menu",
            null,
            [

                getItem("Home", "", <FaHome />),

                (permissionsGet?.Management_view) && getItem('Management Details', 'management_details', <FaWpforms />),
                // ]),
                (permissionsGet?.Family?.View) && getItem('FamilyDetails', 'sub1', <HiUserGroup />, [
                    getItem('AddFamilyDetails', 'family', <MdGroupAdd />),
                    getItem('Family Group', 'family_group', <MdFamilyRestroom />),
                    getItem('Member List', 'member_list', <HiOutlineClipboardDocumentList />),
                ]),
                (permissionsGet?.Authority?.View) && getItem('Authorities', 'sub2', <MdManageAccounts />, [
                    getItem('Add Authorities', 'add_authorities', <FaWpforms />),
                    getItem('Authorities List', 'view_authoritylist', <HiOutlineClipboardDocumentList />),
                ]),
                (permissionsGet?.Marriage?.View) && getItem('Marriage', 'sub3', <TbHeartHandshake />, [
                    getItem('Marriage', 'Marriage', <FaWpforms />),
                    getItem('Marriage List', 'view_marriagelist', <HiOutlineClipboardDocumentList />),
                ]),
                (permissionsGet?.Festival_list?.View) && getItem('Festival', 'sub4', <GiCrackedBallDunk />, [
                    getItem('AddFestival', 'AddFestival', <FaWpforms />),
                    getItem('FestivalList', 'FestivalList', <HiOutlineClipboardDocumentList />),
                ]),
                (permissionsGet?.Death?.View) && getItem('Death', 'sub5', <RiPassExpiredFill />, [
                    getItem('DeathForm', 'DeathForm', <FaWpforms />),
                    getItem('Death List', 'view_deathlist', <HiOutlineClipboardDocumentList />),
                ]),
                (permissionsGet?.Income?.View) && getItem('Income', 'sub6', <GiMoneyStack />, [
                    getItem('Add Income', 'add_income', <FaWpforms />),
                    getItem('Income List', 'view_income', <HiOutlineClipboardDocumentList />),
                    getItem('Category & Name List', 'income_category_and_Name', <HiOutlineClipboardDocumentList />),
                ]),
                (permissionsGet?.Expense?.View) && getItem('Expense', 'sub7', <FaMoneyBillTrendUp />, [
                    getItem('Add Expense', 'add_expense', <FaWpforms />),
                    getItem('Expense List', 'view_expense', <HiOutlineClipboardDocumentList />),
                ]),

                (permissionsGet?.Fund_list?.View) && getItem('Fund', 'sub8', <GiReceiveMoney />, [
                    getItem(<MenuText style={{ color: 'red', cursor: 'text' }}>{collapsed ? null : 'Create Fund'}</MenuText>, '/', null,),
                    getItem('Create Fund', 'create_fund', <MdAddchart />),
                    getItem('View Fund', 'view_fund', <MdOutlineRateReview />),
                    getItem(<MenuText style={{ color: 'red', cursor: 'text' }}>{collapsed ? null : 'Fund Group'}</MenuText>, '/', null,),
                    getItem('Fund', 'fund', <MdAddchart />),
                    getItem('Fund List', 'view_fundlist', <MdOutlineRateReview />),

                    getItem(<MenuText style={{ color: 'red', cursor: 'text' }}>{collapsed ? null : 'Fund Lease'}</MenuText>, '/', null,),
                    getItem('Fund Lease', 'FundLease', <MdAddchart />),
                    getItem('View Fund Lease', 'view_fund_lease_member', <MdOutlineRateReview />),

                ]),
                (permissionsGet?.Chitfund?.View) && getItem('Chit Fund', 'sub9', <GiTakeMyMoney />, [
                    getItem('Add Chit Fund', 'add_chitfund', <MdAddchart />),
                    getItem('Chit Fund List', 'chit_fund_lists', <MdOutlineRateReview />),
                    getItem(<MenuText style={{ color: 'red', cursor: 'text' }}>{collapsed ? null : 'Investors'}</MenuText>, '/', null,),
                    getItem('Chit Fund Investers', 'chitfund_investors', <MdAddchart />),
                    getItem('View Login Investers', 'chitfund_investors_view', <MdOutlineRateReview />),
                    getItem(<MenuText style={{ color: 'red', cursor: 'text' }}>{collapsed ? null : 'Settlement Application'}</MenuText>, '/', null,),
                    getItem('Settlement Application', 'chitfund_settlement_application', <MdAddchart />),
                    getItem('View Settlement Application', 'view_settlement_application', <MdOutlineRateReview />),
                    getItem(<MenuText style={{ color: 'red', cursor: 'text' }}>{collapsed ? null : 'Chit Settlement'}</MenuText>, '/', null,),
                    getItem('Chit Fund Settlement', 'chitfund_settlement', <MdAddchart />),
                    getItem('View Chit Fund Settlement', 'chit_fund_settlementList', <MdOutlineRateReview />),
                    getItem(<MenuText style={{ color: 'red', cursor: 'text' }}>{collapsed ? null : 'Profit Distribution'}</MenuText>, '/', null,),
                    getItem('Profit Distribution', 'chitfund_profitdistribution', <MdAddchart />),
                    getItem('Profit Distribution List', 'chitfund_profitdistributionlist', <MdOutlineRateReview />),

                    getItem('Terms & Conditions', 'terms_and_conditions', <RiFileList3Line />),
                    getItem('Balance Sheet', 'chitfund_balancesheet', <TbFileInvoice />)
                ]),

                (permissionsGet?.Interest?.View) && getItem('Interest', 'sub10', <HiReceiptTax />, [
                    getItem('Interest', 'Interest', <HiReceiptTax />),
                    getItem('Management Interest', 'management_interest', <HiOfficeBuilding />),
                    getItem('Chit-Fund Interest', 'chit_fund_interest', <GrMoney />),
                ]),

                (permissionsGet?.Marriage?.View) && getItem('Marriage', 'sub11', <TbHeartHandshake />, [
                    getItem('Marriage', 'Marriage', <FaWpforms />),
                    getItem('Marriage List', 'view_marriagelist', <HiOutlineClipboardDocumentList />),
                ]),

                (permissionsGet?.Festival_list?.View) && getItem('Festival', 'sub12', <GiCrackedBallDunk />, [
                    getItem('AddFestival', 'AddFestival', <FaWpforms />),
                    getItem('FestivalList', 'FestivalList', <HiOutlineClipboardDocumentList />),
                ]),

                (permissionsGet?.Assets?.View) && getItem('Asset', 'sub13', <LuTableProperties />, [
                    getItem('AssetDetails', 'AssetDetails', <BsBoxSeam />),
                    getItem('Asset List', 'asset_list', <HiOutlineClipboardDocumentList />),
                ]),
                (permissionsGet?.Rental?.View) && getItem('Rental/Lease', 'sub14', <GiLandMine />, [
                    getItem('Rental/Lease', 'rental_lease', <AiTwotoneAccountBook />),
                    getItem('Rental/Lease List', 'RentalandLeaseList', <AiTwotoneAccountBook />),
                ]),

                (permissionsGet?.Sangam?.View) && getItem('Sangam', 'sub15', <FaPeopleGroup />, [
                    getItem('Add Sangam Details', 'add_sangam_details', <FaWpforms />),
                    getItem('Sangam List', 'view_sangamlist', <HiOutlineClipboardDocumentList />),
                ]),

                (permissionsGet?.SubTariff?.View) && getItem('Subscription Tariff', 'sub16', <MdOutlineGpsFixed />, [
                    getItem('SetSubscriptionTariff', 'SetSubscriptionTariff', <FaWpforms />),
                    getItem('SubscriptionTariff List', 'subscription_tariff_list', <HiOutlineClipboardDocumentList />),
                ]),

                (permissionsGet?.collection) && getItem('Collection Details', 'sub17', <HiClipboardDocumentList />, [
                    getItem('Collection', 'collection', <FaWpforms />),
                    getItem('Collection History', 'CollectionUserList', <HiOutlineClipboardDocumentList />),
                ]),
                (permissionsGet?.Cash_transaction?.View) && getItem('Bank Transaction', 'bank_transaction', <FaWpforms />),
            ], 'group'),
    ]

    return items;
};
export const userKeys = [
    "sub1",
    "sub2",
    "sub3",
    "sub4",
    "sub5",
    "sub6",
    "sub7",
    "sub8",
    "sub9",
    "sub10",
    "sub11",
    "sub12",
    "sub13",
    "sub14",
    "sub15",
    "sub16",
    "sub17",
];
