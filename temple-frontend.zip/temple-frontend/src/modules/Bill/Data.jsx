export const data = [
    {
        reason: 'Death Tariff',
        billamount: 100.00,
    },
    {
        reason: 'Death Tariff',
        billamount: 100.00,
    },
    {
        reason: 'Death Tariff',
        billamount: 100.00,
    },
    {
        reason: 'Death Tariff',
        billamount: 100.00,
    },
   
    
];




