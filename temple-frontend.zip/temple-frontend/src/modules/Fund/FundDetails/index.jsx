import React, { Fragment } from "react";
import ViewFundMemberProfile from "./Partials/ViewFundDetails";

const FundMemberProfile = () => {
  return (
    <Fragment>
      <ViewFundMemberProfile />
    </Fragment>
  );
};

export default FundMemberProfile;
