import React from 'react'
import BalanceSheet from './Partials/BalanceSheet'

export const BalanceSheetOverall = () => {
  return (
    <div>
        <BalanceSheet/>
    </div>
  )
}
