import styled from "styled-components"

export const StyledHeading = styled.div`
    
color: #FF0000;
font-weight: 500;
line-height: normal;

`

export const StyledRadio = styled.div`
    
&.ant-form label {
    padding: 0 18px !important;
}

`