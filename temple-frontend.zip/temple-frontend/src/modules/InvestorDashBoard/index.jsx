import React from 'react'
import { InvestorOverAllDetails } from '@modules/InvestorDashBoard/Partials/InvestorOverAllDetails'


export const InvestorDashBoardDetails = () => {
    return (
        <div>
            <InvestorOverAllDetails />
        </div>
    )
}
