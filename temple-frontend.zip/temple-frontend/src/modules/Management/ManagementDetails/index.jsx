import React, { Fragment} from "react";
import AddManagementForm from "./Partials/ManagementDetails";

const ManagementDetails = () => {
  return (
    <Fragment>
      <AddManagementForm />
    </Fragment>
  );
};
export default ManagementDetails;
