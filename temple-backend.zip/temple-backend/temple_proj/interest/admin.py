from django.contrib import admin
from .models import PeopleInterestDetails

admin.site.register(PeopleInterestDetails)
