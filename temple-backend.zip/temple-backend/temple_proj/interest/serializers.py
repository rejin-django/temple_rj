from rest_framework import serializers
from .models import PeopleInterestDetails
from rest_framework.exceptions import ValidationError
from django.utils import timezone
import datetime


def interest_no():
    l=PeopleInterestDetails.objects.last()
    if l:
        l=l.id   
    else:
        l=0      
    l=l+1

    return ("INT" '%01d' % l)

class PeopleInterestDetailsSerializer(serializers.ModelSerializer):
    id=serializers.IntegerField(required=False)
    photo=serializers.ImageField(required=False)
    action = serializers.BooleanField(default=True)
    class Meta:
        model =PeopleInterestDetails
        fields = '__all__'
        
    def create(self, validated_data):
        profile_instance = PeopleInterestDetails.objects.create(intrest_no=interest_no(),**validated_data)               
        return profile_instance
    
    
    def validate(self, validated_data): 
            print(validated_data)       
        # if validated_data['interest_type']=="Chit fund Interest":
            if validated_data['interest_date'] > timezone.now().date():
                raise serializers.ValidationError("Interest date cannot be greater than today") 
            else:                
                current_date = datetime.date.today()
                checking_date=validated_data['interest_date']
                print(checking_date)
                print(checking_date.year)
                print(checking_date.month)
                print(current_date.month - 1)

                if checking_date.year == current_date.year and checking_date.month == current_date.month - 1 or checking_date.year == current_date.year and checking_date.month == current_date.month:
                    print("ccccccccccccccccc")
                    return validated_data
                else:
                    raise serializers.ValidationError("Interest can only be added with the interest date of current month and previous month.")

            