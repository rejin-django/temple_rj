from django.apps import AppConfig


class AmountConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'amount'
