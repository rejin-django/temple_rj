from django.contrib import admin
from .models import *

admin.site.register(ADD_EXFields)
admin.site.register(AddPosition)
admin.site.register(AddAuthorityDetails)
admin.site.register(AutharityFields)
