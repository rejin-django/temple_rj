from django.contrib import admin
from .models import *

admin.site.register(AddSangamName)
admin.site.register(AddSangamDetails)
admin.site.register(SangamMembers)





