from django.test import TestCase
import datetime

a=  datetime.datetime.now().month
print(a) 
                           
