from django.contrib import admin
from .models import ADDFundDetails,FundMemberDetailss,FundGroupDetails,FundLeaseDetailss
admin.site.register(ADDFundDetails)
admin.site.register(FundMemberDetailss)
admin.site.register(FundGroupDetails)
admin.site.register(FundLeaseDetailss)