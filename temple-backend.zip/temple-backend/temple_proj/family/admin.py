from django.contrib import admin
from .models import *

admin.site.register(Fammily_Details)
admin.site.register(Member_Details)
