from .base import *

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'temple-pro',
        'HOST': 'ls-14454cdf92b6d2cd29726e488e48fc7e43f0db9e.c5kylqbgbcgu.ap-south-1.rds.amazonaws.com',
        'PORT': '3306',
        'USER': 'temple-pro',
        'PASSWORD': 'temple@2024',
        'CONN_MAX_AGE': 0,
    }
}


# light shell new bucket
AWS_ACCESS_KEY_ID = 'AKIAQG7H242YBL5RPSXV'
AWS_SECRET_ACCESS_KEY = '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'
AWS_DEFAULT_REGION = 'ap-south-1'
AWS_STORAGE_BUCKET_NAME = 'ideaux-bucket'
AWS_S3_CUSTOM_DOMAIN = f'{AWS_STORAGE_BUCKET_NAME}.s3.{AWS_DEFAULT_REGION}.amazonaws.com'
AWS_LOCATION = 'temple/production/media'

STATIC_URL = f'https://{AWS_S3_CUSTOM_DOMAIN}/{AWS_LOCATION}/'

DEFAULT_FILE_STORAGE = 'storages.backends.s3boto3.S3Boto3Storage'
STATICFILES_STORAGE = 'storages.backends.s3boto3.S3StaticStorage'

