from django.contrib import admin
from .models import ADDIncomeDetails

admin.site.register(ADDIncomeDetails)
