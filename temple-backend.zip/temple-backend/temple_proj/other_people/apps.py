from django.apps import AppConfig


class OtherPeopleConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'other_people'
