from my_tasks.management.schedule import start
start()
