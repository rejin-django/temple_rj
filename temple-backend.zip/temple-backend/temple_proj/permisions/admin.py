from django.contrib import admin
from .models import My_Roles,Permisions

admin.site.register(My_Roles)
admin.site.register(Permisions)

