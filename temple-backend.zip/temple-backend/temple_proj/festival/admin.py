from django.contrib import admin
from .models import ADDFestivalDetails

admin.site.register(ADDFestivalDetails)