from django.contrib import admin
from .models import *


admin.site.register(CollectionDetails)
# Register your models here.
